# Student Fee Manager — Phase 1 + Phase 2 (Redesigned UI)

## 🚀 Bina Android Studio ke APK banao (GitHub Actions - Cloud Build)

Ye tareeka phone se bhi kiya ja sakta hai, sirf browser chahiye:

1. **GitHub account banao**: github.com pe jao, "Sign up" karo (free)
2. **Naya repository banao**: "+" → "New repository" → naam do "StudentFeeManager" → Public rakho → "Create repository"
3. **Sab files upload karo**: Repository page pe "Add file" → "Upload files" → is poore ZIP ke andar ka `StudentFeeManager` folder ka pura content (sabhi files/folders, `.github` folder bhi shaamil) select karke upload karo. Folder structure exactly waisa hi rehna chahiye.
4. **Commit changes** dabao (neeche button)
5. Ab apni repository ke top pe **"Actions"** tab pe jao
6. "Build APK" workflow dikhega — usme click karo → **"Run workflow"** button dabao → "Run workflow" phir se confirm karo
7. 2-5 minute wait karo (cloud pe build ho raha hoga - green tick ka wait karo)
8. Build complete hone ke baad us run pe click karo → neeche **"Artifacts"** section mein **"app-debug-apk"** milega → download kar lo (zip aayega, usme APK hoga)
9. Us APK file ko phone mein bhej do (khud ko email/Drive/WhatsApp kar do) aur install kar lo

**Note**: Har baar jab code mein koi change karoge (naya phase add hoga), yehi files GitHub pe re-upload karke "Run workflow" phir se chalana hoga naya APK paane ke liye.

---


## UI Redesign

App ka look ab "Tuition Tracker" reference design jaisa hai:
- Green gradient hero card (Dashboard pe "Collected" amount, Pending/Target badges)
- Quick action buttons (Add Student, Record Payment)
- 2x2 stat cards grid (Total Students, Paid This Month, Yet to Pay, Total Outstanding)
- Recent Payments list
- Student list mein filter chips: All / Paid / Partial / Unpaid / Pending
- Har student card pe seedha WhatsApp button
- Bottom nav: Home, Students, Reports, Settings (Reports & Settings abhi placeholder hain, Phase 3 mein banenge)


Phase 1: Project Setup + Student Management (Add/Edit/Delete/List/Search).
Phase 2: Custom Fee Cycle Tracking + Payment History + Dashboard + WhatsApp Reminder.

## Phase 2 - Custom Fee Cycle (IMPORTANT)

Har student ka apna personal fee due date hota hai, based on unki Admission Date pe:
- Student 5 tareek ko join kare -> fee har mahine 5 tareek ko due hogi, cycle 5 se agle mahine ki 4 tareek tak
- Student 10 tareek ko join kare -> fee har mahine 10 tareek ko due hogi
- Agar wo din us mahine mein exist nahi karta (jaise 31), to us mahine ki last valid date use hogi (jaise 30 ya 28/29 Feb)

Ye sab automatic hai — bas Student add karte waqt "Admission Date" sahi daal dena, baaki app khud calculate kar lega. Fee cycles automatically generate hote hain jab bhi app khulti hai (naya mahina start hote hi naya cycle apne aap ban jata hai).

## Kaise Open Karein (Android Studio mein)

1. Android Studio install karke kholo.
2. "Open" (ya "Open an Existing Project") click karo.
3. Ye `StudentFeeManager` folder select karo (jisme `build.gradle.kts` hai).
4. Android Studio "Gradle Sync" khud shuru karega — 2-5 minute lagega
   (pehli baar internet download karega dependencies ke liye).
5. Sync complete hone ke baad, phone ko USB se connect karo
   (USB Debugging on karke) ya Emulator start karo.
6. Upar Green "Run" button (▶) dabao.
7. App phone/emulator par install ho jayegi automatically.

## Ab tak kya kaam karta hai

- Dashboard: total students, is mahine ka collection, pending amount, students yet to pay
- Naya student add karo (Add button - bottom right "+"), Admission Date sahi daalo
- Student list dekho, search karo naam/class se
- Kisi student ke profile mein: Payment History (har month cycle), Total Paid, Total Pending
- Kisi bhi month cycle pe tap karke payment record karo (Amount, Method: Cash/UPI/Bank/Other, Remarks)
- WhatsApp Reminder button — message edit karke bhej sakte ho
- Sab data phone mein hi local save hota hai (Room Database) — internet ki zaroorat nahi

## Agla Phase (Phase 3)

- Search & Filters (class, paid/unpaid/partial se filter)
- Reports (custom date range, student-wise collection)
- Statistics charts (monthly/yearly income graph)
- Notifications (WorkManager se month start reminder)
- PDF/Excel Export, App Lock (PIN/Fingerprint), Settings

Jab ye phase test kar lo, mujhe bata dena — Phase 3 ka code dunga.

## Common Issues

- **Gradle sync fail ho raha hai**: Internet connection check karo, phir
  "File > Sync Project with Gradle Files" try karo.
- **"SDK not found"**: Android Studio khud SDK download karne ka prompt dega,
  usko allow kar do.
- **App crash ho raha hai**: "Logcat" tab (niche) khol ke red error text
  mujhe bhej dena, main fix kar dunga.
