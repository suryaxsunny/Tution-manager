package com.sunny.studentfeemanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sunny.studentfeemanager.ui.theme.BackgroundLight
import com.sunny.studentfeemanager.ui.theme.TextPrimary
import com.sunny.studentfeemanager.ui.theme.TextSecondary

/**
 * Placeholder for Phase 3. Will show monthly/yearly income charts,
 * custom date-range reports, and student-wise collection breakdowns.
 */
@Composable
fun ReportsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.BarChart,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = TextSecondary.copy(alpha = 0.4f)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text("Reports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            "Coming in Phase 3: income charts & custom reports",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
    }
}
