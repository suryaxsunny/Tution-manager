package com.sunny.studentfeemanager.data

import androidx.room.TypeConverter
import com.sunny.studentfeemanager.data.model.PaymentMethod
import com.sunny.studentfeemanager.data.model.PaymentStatus

/**
 * Room can only store primitive types (String, Int, Long, etc.) in the database.
 * These converters teach Room how to save/load our enum types.
 */
class Converters {

    @TypeConverter
    fun fromPaymentStatus(status: PaymentStatus): String = status.name

    @TypeConverter
    fun toPaymentStatus(value: String): PaymentStatus = PaymentStatus.valueOf(value)

    @TypeConverter
    fun fromPaymentMethod(method: PaymentMethod?): String? = method?.name

    @TypeConverter
    fun toPaymentMethod(value: String?): PaymentMethod? = value?.let { PaymentMethod.valueOf(it) }
}
