package com.sunny.studentfeemanager.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

enum class PaymentStatus {
    PAID, PARTIAL, UNPAID
}

enum class PaymentMethod {
    CASH, UPI, BANK_TRANSFER, OTHER
}

/**
 * Represents ONE fee cycle (month) for ONE student.
 * cycleStartDate is the student's personal due date for that month
 * (e.g. if admission was on the 5th, cycleStartDate will always be the 5th).
 *
 * This is linked to a Student via studentId.
 */
@Entity(
    tableName = "fee_records",
    foreignKeys = [
        ForeignKey(
            entity = Student::class,
            parentColumns = ["id"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE // if student is deleted, their fee records are deleted too
        )
    ]
)
data class FeeRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val studentId: Long,

    // The due date for this cycle (epoch millis). E.g. if student joined on the 5th,
    // this will be the 5th of whichever month this record covers.
    val cycleStartDate: Long,

    // The day before the next cycle's due date (epoch millis)
    val cycleEndDate: Long,

    val monthlyFee: Double,        // Fee amount at the time this record was generated
    val amountPaid: Double = 0.0,
    val paymentDate: Long? = null, // null = not paid yet
    val paymentMethod: PaymentMethod? = null,
    val remarks: String = "",

    val status: PaymentStatus = PaymentStatus.UNPAID
) {
    val remainingBalance: Double
        get() = (monthlyFee - amountPaid).coerceAtLeast(0.0)
}
