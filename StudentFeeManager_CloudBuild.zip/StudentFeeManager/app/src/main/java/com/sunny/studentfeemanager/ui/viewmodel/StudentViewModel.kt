package com.sunny.studentfeemanager.ui.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.sunny.studentfeemanager.data.AppDatabase
import com.sunny.studentfeemanager.data.model.Student
import com.sunny.studentfeemanager.data.repository.StudentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel = holds UI state and survives screen rotation.
 * The Compose screens will observe the StateFlows below and
 * automatically redraw whenever the data changes.
 */
class StudentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StudentRepository

    // Search text typed by the user
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    init {
        val dao = AppDatabase.getDatabase(application).studentDao()
        repository = StudentRepository(dao)
    }

    // The full student list, always up to date, shown on the list screen
    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Total count of active students (for Dashboard use later)
    val activeStudentCount: StateFlow<Int> = repository.activeStudentCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun addStudent(student: Student) {
        viewModelScope.launch {
            repository.insertStudent(student)
        }
    }

    fun updateStudent(student: Student) {
        viewModelScope.launch {
            repository.updateStudent(student)
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
        }
    }

    fun getStudentById(id: Long) = repository.getStudentById(id)
}

/**
 * Factory needed because our ViewModel needs the Application context
 * to access the database.
 */
class StudentViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudentViewModel::class.java)) {
            return StudentViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
