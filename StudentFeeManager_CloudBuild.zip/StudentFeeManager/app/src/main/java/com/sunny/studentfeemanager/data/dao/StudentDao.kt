package com.sunny.studentfeemanager.data.dao

import androidx.room.*
import com.sunny.studentfeemanager.data.model.Student
import kotlinx.coroutines.flow.Flow

/**
 * DAO = Data Access Object.
 * This defines every database operation we can do on the "students" table.
 * Room automatically writes the actual SQL implementation for us.
 */
@Dao
interface StudentDao {

    // Insert a new student. Returns the new row's ID.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    // Update an existing student's details
    @Update
    suspend fun updateStudent(student: Student)

    // Delete a student
    @Delete
    suspend fun deleteStudent(student: Student)

    // Get all students, sorted by name.
    // Flow means the UI will automatically update if data changes.
    @Query("SELECT * FROM students ORDER BY fullName ASC")
    fun getAllStudents(): Flow<List<Student>>

    // Get only active students
    @Query("SELECT * FROM students WHERE isActive = 1 ORDER BY fullName ASC")
    fun getActiveStudents(): Flow<List<Student>>

    // Get one student by ID (for the profile / edit screen)
    @Query("SELECT * FROM students WHERE id = :studentId")
    fun getStudentById(studentId: Long): Flow<Student?>

    // Search students by name (for the search bar)
    @Query("SELECT * FROM students WHERE fullName LIKE '%' || :query || '%' ORDER BY fullName ASC")
    fun searchStudents(query: String): Flow<List<Student>>

    // Filter students by class/grade
    @Query("SELECT * FROM students WHERE classGrade = :classGrade ORDER BY fullName ASC")
    fun getStudentsByClass(classGrade: String): Flow<List<Student>>

    // Count total students (used on Dashboard)
    @Query("SELECT COUNT(*) FROM students WHERE isActive = 1")
    fun getActiveStudentCount(): Flow<Int>
}
