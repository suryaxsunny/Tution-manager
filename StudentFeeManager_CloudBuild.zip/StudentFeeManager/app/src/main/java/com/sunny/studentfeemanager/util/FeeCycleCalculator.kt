package com.sunny.studentfeemanager.util

import java.util.Calendar

/**
 * This is the "brain" behind custom fee cycles.
 *
 * Every student has their own personal due date based on their admission date.
 * Example: Student joined on the 5th -> fee is due on the 5th every month,
 * and each "cycle" runs from the 5th of one month to the 4th of the next.
 *
 * If the admission day doesn't exist in a later month (e.g. 31st in February),
 * we "clamp" to the last valid day of that month instead (e.g. 28th/29th).
 */
object FeeCycleCalculator {

    data class Cycle(
        val cycleStartMillis: Long,  // due date for this cycle
        val cycleEndMillis: Long     // day before the next due date
    )

    /**
     * Returns the day-of-month clamped to a valid day for the given year/month.
     * E.g. clampDay(2026, FEBRUARY, 31) -> 28 (or 29 in a leap year)
     */
    private fun clampDay(year: Int, month: Int, day: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(year, month, 1)
        val lastDayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        return minOf(day, lastDayOfMonth)
    }

    /**
     * Builds a Calendar set to a specific clamped day within a given year/month.
     */
    private fun buildDate(year: Int, month: Int, day: Int): Calendar {
        val clampedDay = clampDay(year, month, day)
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(year, month, clampedDay, 0, 0, 0)
        return cal
    }

    /**
     * Given a student's admission date, returns every fee cycle from admission
     * up to (and including) the cycle that covers "today".
     *
     * This is what generates the monthly fee records automatically.
     */
    fun getAllCyclesUpToToday(admissionDateMillis: Long): List<Cycle> {
        val admissionCal = Calendar.getInstance().apply { timeInMillis = admissionDateMillis }
        val dueDay = admissionCal.get(Calendar.DAY_OF_MONTH)

        val today = Calendar.getInstance()
        today.set(Calendar.HOUR_OF_DAY, 0)
        today.set(Calendar.MINUTE, 0)
        today.set(Calendar.SECOND, 0)
        today.set(Calendar.MILLISECOND, 0)

        val cycles = mutableListOf<Cycle>()

        var year = admissionCal.get(Calendar.YEAR)
        var month = admissionCal.get(Calendar.MONTH)
        var cycleStart = buildDate(year, month, dueDay)

        // Keep generating cycles until the cycle start date is in the future
        while (cycles.isEmpty() || !cycleStart.after(today)) {
            // Next cycle's start = next month's due day (clamped)
            var nextMonth = month + 1
            var nextYear = year
            if (nextMonth > Calendar.DECEMBER) {
                nextMonth = Calendar.JANUARY
                nextYear += 1
            }
            val nextCycleStart = buildDate(nextYear, nextMonth, dueDay)

            // This cycle ends the day before the next cycle starts
            val cycleEnd = (nextCycleStart.clone() as Calendar).apply {
                add(Calendar.DAY_OF_MONTH, -1)
            }

            cycles.add(
                Cycle(
                    cycleStartMillis = cycleStart.timeInMillis,
                    cycleEndMillis = cycleEnd.timeInMillis
                )
            )

            if (cycleStart.after(today)) break

            year = nextYear
            month = nextMonth
            cycleStart = nextCycleStart
        }

        return cycles
    }

    /**
     * Returns just the CURRENT active cycle (the one covering today) for a student.
     * Useful for "this month's" dashboard calculations.
     */
    fun getCurrentCycle(admissionDateMillis: Long): Cycle {
        return getAllCyclesUpToToday(admissionDateMillis).last()
    }

    /**
     * Returns the due-day-of-month for display purposes (e.g. "5th of every month").
     */
    fun getDueDay(admissionDateMillis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = admissionDateMillis }
        return cal.get(Calendar.DAY_OF_MONTH)
    }
}
