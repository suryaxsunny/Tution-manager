package com.sunny.studentfeemanager.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sunny.studentfeemanager.ui.screens.*
import com.sunny.studentfeemanager.ui.theme.GreenPrimary
import com.sunny.studentfeemanager.ui.theme.SurfaceLight
import com.sunny.studentfeemanager.ui.theme.TextSecondary
import com.sunny.studentfeemanager.ui.viewmodel.FeeRecordViewModel
import com.sunny.studentfeemanager.ui.viewmodel.StudentViewModel
import com.sunny.studentfeemanager.util.WhatsAppHelper

object Routes {
    const val DASHBOARD = "dashboard"
    const val STUDENT_LIST = "student_list"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
    const val ADD_STUDENT = "add_student"
    const val EDIT_STUDENT = "edit_student/{studentId}"
    const val STUDENT_PROFILE = "student_profile/{studentId}"

    fun editStudent(studentId: Long) = "edit_student/$studentId"
    fun studentProfile(studentId: Long) = "student_profile/$studentId"
}

private val bottomNavRoutes = listOf(Routes.DASHBOARD, Routes.STUDENT_LIST, Routes.REPORTS, Routes.SETTINGS)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val studentViewModel: StudentViewModel = viewModel()
    val feeViewModel: FeeRecordViewModel = viewModel()
    val context = LocalContext.current

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomNavRoutes) {
                NavigationBar(containerColor = SurfaceLight) {
                    NavigationBarItem(
                        selected = currentRoute == Routes.DASHBOARD,
                        onClick = { navController.navigate(Routes.DASHBOARD) { popUpTo(Routes.DASHBOARD) { inclusive = true } } },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        colors = navItemColors()
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.STUDENT_LIST,
                        onClick = { navController.navigate(Routes.STUDENT_LIST) { popUpTo(Routes.DASHBOARD) } },
                        icon = { Icon(Icons.Default.People, contentDescription = "Students") },
                        label = { Text("Students") },
                        colors = navItemColors()
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.REPORTS,
                        onClick = { navController.navigate(Routes.REPORTS) { popUpTo(Routes.DASHBOARD) } },
                        icon = { Icon(Icons.Default.BarChart, contentDescription = "Reports") },
                        label = { Text("Reports") },
                        colors = navItemColors()
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.SETTINGS,
                        onClick = { navController.navigate(Routes.SETTINGS) { popUpTo(Routes.DASHBOARD) } },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                        colors = navItemColors()
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = androidx.compose.ui.Modifier.padding(innerPadding)
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    viewModel = feeViewModel,
                    onViewStudentsClick = { navController.navigate(Routes.STUDENT_LIST) },
                    onAddStudentClick = { navController.navigate(Routes.ADD_STUDENT) },
                    onRecordPaymentClick = { navController.navigate(Routes.STUDENT_LIST) }
                )
            }

            composable(Routes.STUDENT_LIST) {
                StudentListScreen(
                    viewModel = studentViewModel,
                    feeViewModel = feeViewModel,
                    onAddStudentClick = { navController.navigate(Routes.ADD_STUDENT) },
                    onStudentClick = { studentId -> navController.navigate(Routes.studentProfile(studentId)) }
                )
            }

            composable(Routes.REPORTS) { ReportsScreen() }
            composable(Routes.SETTINGS) { SettingsScreen() }

            composable(Routes.ADD_STUDENT) {
                AddEditStudentScreen(
                    viewModel = studentViewModel,
                    existingStudent = null,
                    onSaveComplete = { navController.popBackStack() },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.EDIT_STUDENT,
                arguments = listOf(navArgument("studentId") { type = NavType.LongType })
            ) { backStackEntry ->
                val studentId = backStackEntry.arguments?.getLong("studentId") ?: 0L
                val student by studentViewModel.getStudentById(studentId).collectAsState(initial = null)

                student?.let {
                    AddEditStudentScreen(
                        viewModel = studentViewModel,
                        existingStudent = it,
                        onSaveComplete = { navController.popBackStack() },
                        onBackClick = { navController.popBackStack() }
                    )
                }
            }

            composable(
                route = Routes.STUDENT_PROFILE,
                arguments = listOf(navArgument("studentId") { type = NavType.LongType })
            ) { backStackEntry ->
                val studentId = backStackEntry.arguments?.getLong("studentId") ?: 0L
                var reminderMessage by remember { mutableStateOf<String?>(null) }
                var reminderStudent by remember { mutableStateOf<com.sunny.studentfeemanager.data.model.Student?>(null) }

                StudentProfileScreen(
                    studentId = studentId,
                    studentViewModel = studentViewModel,
                    feeViewModel = feeViewModel,
                    onBackClick = { navController.popBackStack() },
                    onEditClick = { navController.navigate(Routes.editStudent(studentId)) },
                    onSendReminderClick = { student, record ->
                        reminderStudent = student
                        reminderMessage = WhatsAppHelper.buildReminderMessage(student, record)
                    }
                )

                if (reminderMessage != null && reminderStudent != null) {
                    ReminderDialog(
                        initialMessage = reminderMessage!!,
                        onDismiss = {
                            reminderMessage = null
                            reminderStudent = null
                        },
                        onSend = { finalMessage ->
                            WhatsAppHelper.openWhatsAppReminder(context, reminderStudent!!, finalMessage)
                            reminderMessage = null
                            reminderStudent = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = GreenPrimary,
    selectedTextColor = GreenPrimary,
    unselectedIconColor = TextSecondary,
    unselectedTextColor = TextSecondary,
    indicatorColor = androidx.compose.ui.graphics.Color.Transparent
)
