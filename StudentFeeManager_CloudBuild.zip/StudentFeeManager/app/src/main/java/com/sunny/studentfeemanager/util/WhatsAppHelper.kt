package com.sunny.studentfeemanager.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.Student
import java.text.SimpleDateFormat
import java.util.*

object WhatsAppHelper {

    /**
     * Builds the default reminder message text for a student's current fee cycle.
     */
    fun buildReminderMessage(student: Student, record: FeeRecord?): String {
        val monthFormat = SimpleDateFormat("MMMM", Locale.getDefault())
        val monthName = record?.let { monthFormat.format(Date(it.cycleStartDate)) }
            ?: monthFormat.format(Date())

        val fee = record?.monthlyFee ?: student.monthlyFee
        val paid = record?.amountPaid ?: 0.0
        val remaining = record?.remainingBalance ?: fee

        return "Hello, your child's tuition fee for $monthName is ₹${fee.toInt()}. " +
            "You have already paid ₹${paid.toInt()}. Remaining balance: ₹${remaining.toInt()}. " +
            "Kindly pay the pending amount. Thank you."
    }

    /**
     * Opens WhatsApp with the parent's number and a pre-filled message.
     * The user can still edit the message inside WhatsApp before sending.
     */
    fun openWhatsAppReminder(context: Context, student: Student, message: String) {
        val cleanNumber = student.mobileNumber.filter { it.isDigit() }
        // Add India country code if a plain 10-digit number was stored
        val fullNumber = if (cleanNumber.length == 10) "91$cleanNumber" else cleanNumber

        val url = "https://wa.me/$fullNumber?text=${Uri.encode(message)}"

        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        }
    }
}
