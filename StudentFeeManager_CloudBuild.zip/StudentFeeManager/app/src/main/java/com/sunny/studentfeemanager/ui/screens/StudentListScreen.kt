package com.sunny.studentfeemanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GroupOff
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunny.studentfeemanager.data.model.PaymentStatus
import com.sunny.studentfeemanager.data.model.Student
import com.sunny.studentfeemanager.ui.theme.*
import com.sunny.studentfeemanager.ui.viewmodel.FeeRecordViewModel
import com.sunny.studentfeemanager.ui.viewmodel.StudentViewModel
import com.sunny.studentfeemanager.util.FeeCycleCalculator
import com.sunny.studentfeemanager.util.WhatsAppHelper

enum class StudentFilter(val label: String) {
    ALL("All"), PAID("Paid"), PARTIAL("Partial"), UNPAID("Unpaid"), PENDING("Pending")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentListScreen(
    viewModel: StudentViewModel = viewModel(),
    feeViewModel: FeeRecordViewModel = viewModel(),
    onAddStudentClick: () -> Unit,
    onStudentClick: (Long) -> Unit
) {
    val students by viewModel.allStudents.collectAsState()
    val allRecords by feeViewModel.allFeeRecordsFlow.collectAsState()
    var searchText by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(StudentFilter.ALL) }
    val context = androidx.compose.ui.platform.LocalContext.current

    // Compute each student's current-cycle status for filtering + badges
    val studentStatuses = remember(students, allRecords) {
        students.associate { s ->
            val cycle = FeeCycleCalculator.getCurrentCycle(s.admissionDate)
            val record = allRecords.find { it.studentId == s.id && it.cycleStartDate == cycle.cycleStartMillis }
            s.id to record
        }
    }

    val filtered = remember(students, searchText, selectedFilter, studentStatuses) {
        students.filter { s ->
            val matchesSearch = searchText.isBlank() ||
                s.fullName.contains(searchText, ignoreCase = true) ||
                s.classGrade.contains(searchText, ignoreCase = true)

            val record = studentStatuses[s.id]
            val matchesFilter = when (selectedFilter) {
                StudentFilter.ALL -> true
                StudentFilter.PAID -> record?.status == PaymentStatus.PAID
                StudentFilter.PARTIAL -> record?.status == PaymentStatus.PARTIAL
                StudentFilter.UNPAID -> record == null || record.status == PaymentStatus.UNPAID
                StudentFilter.PENDING -> (record?.remainingBalance ?: 0.0) > 0.0
            }
            matchesSearch && matchesFilter
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Students",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Surface(
                    onClick = onAddStudentClick,
                    shape = CircleShape,
                    color = GreenPrimary
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add Student",
                        tint = androidx.compose.ui.graphics.Color.White,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search by name...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = SurfaceLight,
                    focusedContainerColor = SurfaceLight,
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedBorderColor = GreenPrimary
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(StudentFilter.values().toList()) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GreenPrimary,
                            selectedLabelColor = androidx.compose.ui.graphics.Color.White,
                            containerColor = SurfaceLight,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            EmptyStudentState(hasStudents = students.isNotEmpty())
        } else {
            LazyColumn(
                modifier = Modifier.padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(filtered, key = { it.id }) { student ->
                    val record = studentStatuses[student.id]
                    StudentCard(
                        student = student,
                        status = record?.status ?: PaymentStatus.UNPAID,
                        dueAmount = record?.remainingBalance ?: student.monthlyFee,
                        onClick = { onStudentClick(student.id) },
                        onWhatsAppClick = {
                            val message = WhatsAppHelper.buildReminderMessage(student, record)
                            WhatsAppHelper.openWhatsAppReminder(context, student, message)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StudentCard(
    student: Student,
    status: PaymentStatus,
    dueAmount: Double,
    onClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceLight
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = GreenLight,
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = initials(student.fullName),
                        style = MaterialTheme.typography.titleSmall,
                        color = GreenPrimaryDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    student.fullName,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary
                )
                Text(
                    "Class ${student.classGrade}${if (student.schoolName.isNotBlank()) " · ${student.schoolName}" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadgeSmall(status)
                    if (dueAmount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Due ₹${dueAmount.toInt()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            Surface(
                onClick = onWhatsAppClick,
                shape = CircleShape,
                color = androidx.compose.ui.graphics.Color(0xFF25D366)
            ) {
                Icon(
                    imageVector = com.sunny.studentfeemanager.ui.icons.WhatsAppIcon,
                    contentDescription = "WhatsApp",
                    tint = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier
                        .padding(9.dp)
                        .size(20.dp)
                )
            }
        }
    }
}

@Composable
fun StatusBadgeSmall(status: PaymentStatus) {
    val (bg, fg, label) = when (status) {
        PaymentStatus.PAID -> Triple(PaidGreenBg, PaidGreen, "PAID")
        PaymentStatus.PARTIAL -> Triple(PartialOrangeBg, PartialOrange, "PARTIAL")
        PaymentStatus.UNPAID -> Triple(UnpaidRedBg, UnpaidRed, "UNPAID")
    }
    Surface(color = bg, shape = RoundedCornerShape(20.dp)) {
        Text(
            label,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun EmptyStudentState(hasStudents: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            if (hasStudents) Icons.Default.PersonSearch else Icons.Default.GroupOff,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = TextSecondary.copy(alpha = 0.4f)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            if (hasStudents) "No students found" else "No students yet",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            if (hasStudents) "Try a different search or filter" else "Tap + to add your first student",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
    }
}

private fun initials(name: String): String {
    val parts = name.trim().split(" ").filter { it.isNotBlank() }
    return when {
        parts.size >= 2 -> "${parts[0].first()}${parts[1].first()}".uppercase()
        parts.size == 1 -> parts[0].take(2).uppercase()
        else -> "?"
    }
}
