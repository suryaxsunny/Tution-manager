package com.sunny.studentfeemanager.data.repository

import com.sunny.studentfeemanager.data.dao.StudentDao
import com.sunny.studentfeemanager.data.model.Student
import kotlinx.coroutines.flow.Flow

/**
 * Repository is the "middle-man" between the ViewModel and the database.
 * Right now it just forwards calls to the DAO, but later this is where
 * we'd also add things like cloud sync, caching, etc.
 */
class StudentRepository(private val studentDao: StudentDao) {

    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val activeStudents: Flow<List<Student>> = studentDao.getActiveStudents()
    val activeStudentCount: Flow<Int> = studentDao.getActiveStudentCount()

    suspend fun insertStudent(student: Student): Long {
        return studentDao.insertStudent(student)
    }

    suspend fun updateStudent(student: Student) {
        studentDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        studentDao.deleteStudent(student)
    }

    fun getStudentById(id: Long): Flow<Student?> {
        return studentDao.getStudentById(id)
    }

    fun searchStudents(query: String): Flow<List<Student>> {
        return studentDao.searchStudents(query)
    }

    fun getStudentsByClass(classGrade: String): Flow<List<Student>> {
        return studentDao.getStudentsByClass(classGrade)
    }
}
