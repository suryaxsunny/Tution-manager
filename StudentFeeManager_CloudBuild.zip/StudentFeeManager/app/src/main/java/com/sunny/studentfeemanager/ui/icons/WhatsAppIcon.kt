package com.sunny.studentfeemanager.ui.icons

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * We use Material's built-in "Chat" bubble icon as a stand-in for the WhatsApp icon.
 * (Using the real WhatsApp logo would require adding WhatsApp's brand assets,
 * which isn't included by default — this keeps the UI clean without extra asset setup.)
 */
val WhatsAppIcon: ImageVector
    get() = Icons.Default.Chat
