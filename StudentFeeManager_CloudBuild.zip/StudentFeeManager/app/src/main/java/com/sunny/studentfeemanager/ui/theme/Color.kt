package com.sunny.studentfeemanager.ui.theme

import androidx.compose.ui.graphics.Color

// ===== Primary Green Theme (matches Tuition Tracker reference design) =====
val GreenPrimary = Color(0xFF1B5E3A)       // deep forest green (buttons, active nav)
val GreenPrimaryDark = Color(0xFF0F3D26)   // darker shade for gradient hero card
val GreenAccent = Color(0xFF2E7D4F)        // mid green for gradient
val GreenLight = Color(0xFFE7F3EC)         // pale green background chips

val BackgroundLight = Color(0xFFF7F7F2)    // warm off-white app background
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceMuted = Color(0xFFF1F1EC)       // used for empty-state icon circles etc.

val TextPrimary = Color(0xFF1A1D1B)
val TextSecondary = Color(0xFF6B7570)

// ===== Status colors (Paid / Partial / Unpaid / Pending) =====
val PaidGreen = Color(0xFF2E7D4F)
val PaidGreenBg = Color(0xFFE3F3E9)

val PartialOrange = Color(0xFFC97A1F)
val PartialOrangeBg = Color(0xFFFBEEDD)

val UnpaidRed = Color(0xFFB3435A)
val UnpaidRedBg = Color(0xFFFAEAEC)

val PendingYellow = Color(0xFF9C7A1A)
val PendingYellowBg = Color(0xFFF7F0DA)

// ===== Dark theme variants =====
val GreenPrimaryDarkTheme = Color(0xFF7BC79E)
val BackgroundDark = Color(0xFF121712)
val SurfaceDark = Color(0xFF1C221D)
