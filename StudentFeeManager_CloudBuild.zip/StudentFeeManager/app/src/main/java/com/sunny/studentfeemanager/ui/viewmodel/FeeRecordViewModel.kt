package com.sunny.studentfeemanager.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sunny.studentfeemanager.data.AppDatabase
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.PaymentMethod
import com.sunny.studentfeemanager.data.model.PaymentStatus
import com.sunny.studentfeemanager.data.repository.FeeRecordRepository
import com.sunny.studentfeemanager.data.repository.StudentRepository
import com.sunny.studentfeemanager.util.FeeCycleCalculator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardStats(
    val totalStudents: Int = 0,
    val totalMonthlyCollection: Double = 0.0,   // sum of everyone's monthly fee (expected income)
    val collectedThisMonth: Double = 0.0,       // actually collected this month
    val pendingAmount: Double = 0.0,            // total outstanding across all students
    val studentsWithPending: Int = 0,
    val studentsPaidThisMonth: Int = 0
)

class FeeRecordViewModel(application: Application) : AndroidViewModel(application) {

    private val feeRecordRepository: FeeRecordRepository
    private val studentRepository: StudentRepository

    init {
        val db = AppDatabase.getDatabase(application)
        feeRecordRepository = FeeRecordRepository(db.feeRecordDao())
        studentRepository = StudentRepository(db.studentDao())

        // Whenever the student list changes, make sure everyone's fee cycles are up to date.
        // This is what auto-generates a new month's fee record once it becomes due.
        viewModelScope.launch {
            studentRepository.activeStudents.collect { students ->
                students.forEach { student ->
                    feeRecordRepository.ensureFeeRecordsUpToDate(student)
                }
            }
        }
    }

    fun getRecordsForStudent(studentId: Long): Flow<List<FeeRecord>> {
        return feeRecordRepository.getRecordsForStudent(studentId)
    }

    fun recordPayment(
        record: FeeRecord,
        amountPaid: Double,
        paymentDate: Long,
        paymentMethod: PaymentMethod,
        remarks: String
    ) {
        viewModelScope.launch {
            feeRecordRepository.recordPayment(record, amountPaid, paymentDate, paymentMethod, remarks)
        }
    }

    // All fee records as a StateFlow, used by the Student List screen for filter chips & badges
    val allFeeRecordsFlow: StateFlow<List<FeeRecord>> = feeRecordRepository.allFeeRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Most recent 5 payments (records that actually have a paymentDate), newest first.
    // Used for the "Recent Payments" list on the Dashboard.
    val recentPayments: StateFlow<List<FeeRecord>> = feeRecordRepository.allFeeRecords
        .map { records ->
            records
                .filter { it.paymentDate != null && it.amountPaid > 0.0 }
                .sortedByDescending { it.paymentDate }
                .take(5)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Combines students + fee records into one Dashboard stats object
    val dashboardStats: StateFlow<DashboardStats> = combine(
        studentRepository.activeStudents,
        feeRecordRepository.allFeeRecords
    ) { students, allRecords ->

        val today = Calendar.getInstance()
        val currentMonth = today.get(Calendar.MONTH)
        val currentYear = today.get(Calendar.YEAR)

        var collectedThisMonth = 0.0
        var pendingAmount = 0.0
        var studentsWithPending = 0
        var studentsPaidThisMonth = 0

        students.forEach { student ->
            // Find this student's current (latest) cycle
            val studentRecords = allRecords.filter { it.studentId == student.id }
            val currentCycle = FeeCycleCalculator.getCurrentCycle(student.admissionDate)
            val currentRecord = studentRecords.find { it.cycleStartDate == currentCycle.cycleStartMillis }

            if (currentRecord != null) {
                if (currentRecord.status == PaymentStatus.PAID) {
                    studentsPaidThisMonth++
                }
                if (currentRecord.remainingBalance > 0.0) {
                    studentsWithPending++
                }
            }

            // Total pending = sum of remaining balance across ALL of this student's cycles
            pendingAmount += studentRecords.sumOf { it.remainingBalance }

            // Collected this month = payments whose paymentDate falls in the current calendar month
            studentRecords.forEach { record ->
                record.paymentDate?.let { payDate ->
                    val cal = Calendar.getInstance().apply { timeInMillis = payDate }
                    if (cal.get(Calendar.MONTH) == currentMonth && cal.get(Calendar.YEAR) == currentYear) {
                        collectedThisMonth += record.amountPaid
                    }
                }
            }
        }

        DashboardStats(
            totalStudents = students.size,
            totalMonthlyCollection = students.sumOf { it.monthlyFee },
            collectedThisMonth = collectedThisMonth,
            pendingAmount = pendingAmount,
            studentsWithPending = studentsWithPending,
            studentsPaidThisMonth = studentsPaidThisMonth
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardStats()
    )
}

class FeeRecordViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FeeRecordViewModel::class.java)) {
            return FeeRecordViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
