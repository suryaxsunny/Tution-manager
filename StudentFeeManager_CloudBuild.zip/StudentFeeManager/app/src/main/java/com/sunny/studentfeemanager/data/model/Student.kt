package com.sunny.studentfeemanager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents one tuition student.
 * This is the "table" that Room will create in the local database.
 */
@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val fullName: String,
    val parentName: String,
    val mobileNumber: String,       // Used for WhatsApp reminders later
    val classGrade: String,
    val schoolName: String = "",    // Optional
    val monthlyFee: Double,
    val admissionDate: Long,        // Stored as epoch millis
    val address: String = "",       // Optional
    val notes: String = "",         // Optional
    val isActive: Boolean = true
)
