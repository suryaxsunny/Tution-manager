package com.sunny.studentfeemanager.data.dao

import androidx.room.*
import com.sunny.studentfeemanager.data.model.FeeRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface FeeRecordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeeRecord(record: FeeRecord): Long

    @Update
    suspend fun updateFeeRecord(record: FeeRecord)

    @Delete
    suspend fun deleteFeeRecord(record: FeeRecord)

    // All fee records for one student, most recent cycle first (for Payment History screen)
    @Query("SELECT * FROM fee_records WHERE studentId = :studentId ORDER BY cycleStartDate DESC")
    fun getRecordsForStudent(studentId: Long): Flow<List<FeeRecord>>

    // Check if a record already exists for a specific cycle (so we don't duplicate)
    @Query("SELECT * FROM fee_records WHERE studentId = :studentId AND cycleStartDate = :cycleStart LIMIT 1")
    suspend fun getRecordForCycle(studentId: Long, cycleStart: Long): FeeRecord?

    // All fee records across all students (used by Dashboard/Reports)
    @Query("SELECT * FROM fee_records")
    fun getAllFeeRecords(): Flow<List<FeeRecord>>

    // Records where payment was made within a date range (for reports)
    @Query("SELECT * FROM fee_records WHERE paymentDate BETWEEN :startMillis AND :endMillis")
    fun getRecordsInRange(startMillis: Long, endMillis: Long): Flow<List<FeeRecord>>

    // Total amount collected within a date range
    @Query("SELECT COALESCE(SUM(amountPaid), 0) FROM fee_records WHERE paymentDate BETWEEN :startMillis AND :endMillis")
    fun getTotalCollectedInRange(startMillis: Long, endMillis: Long): Flow<Double>
}
