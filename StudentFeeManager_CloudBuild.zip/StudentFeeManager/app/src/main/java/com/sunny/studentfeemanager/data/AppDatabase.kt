package com.sunny.studentfeemanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.sunny.studentfeemanager.data.dao.FeeRecordDao
import com.sunny.studentfeemanager.data.dao.StudentDao
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.Student

/**
 * This is the main database "brain" of the app.
 * Phase 2 adds the FeeRecord table (monthly fee tracking) alongside Student.
 */
@Database(
    entities = [Student::class, FeeRecord::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun studentDao(): StudentDao
    abstract fun feeRecordDao(): FeeRecordDao

    companion object {
        // @Volatile makes sure changes to this variable are visible to all threads immediately
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Singleton pattern: only one database instance ever exists in the app
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "student_fee_manager_db"
                )
                    .fallbackToDestructiveMigration() // simplest approach for now: rebuild DB on version change
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
