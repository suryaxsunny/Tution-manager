package com.sunny.studentfeemanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunny.studentfeemanager.data.model.Student
import com.sunny.studentfeemanager.ui.viewmodel.StudentViewModel

/**
 * Used for BOTH adding a new student and editing an existing one.
 * If existingStudent is null -> "Add" mode. Otherwise -> "Edit" mode.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditStudentScreen(
    viewModel: StudentViewModel = viewModel(),
    existingStudent: Student? = null,
    onSaveComplete: () -> Unit,
    onBackClick: () -> Unit
) {
    var fullName by remember { mutableStateOf(existingStudent?.fullName ?: "") }
    var parentName by remember { mutableStateOf(existingStudent?.parentName ?: "") }
    var mobileNumber by remember { mutableStateOf(existingStudent?.mobileNumber ?: "") }
    var classGrade by remember { mutableStateOf(existingStudent?.classGrade ?: "") }
    var schoolName by remember { mutableStateOf(existingStudent?.schoolName ?: "") }
    var monthlyFee by remember { mutableStateOf(existingStudent?.monthlyFee?.toString() ?: "") }
    var address by remember { mutableStateOf(existingStudent?.address ?: "") }
    var notes by remember { mutableStateOf(existingStudent?.notes ?: "") }

    // Simple validation flags
    var nameError by remember { mutableStateOf(false) }
    var mobileError by remember { mutableStateOf(false) }
    var feeError by remember { mutableStateOf(false) }

    val isEditMode = existingStudent != null

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "Edit Student" else "Add Student") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it; nameError = false },
                label = { Text("Full Name *") },
                isError = nameError,
                supportingText = { if (nameError) Text("Name is required") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = parentName,
                onValueChange = { parentName = it },
                label = { Text("Parent's Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = mobileNumber,
                onValueChange = { mobileNumber = it; mobileError = false },
                label = { Text("Mobile Number (WhatsApp) *") },
                isError = mobileError,
                supportingText = { if (mobileError) Text("Valid 10-digit number required") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = classGrade,
                onValueChange = { classGrade = it },
                label = { Text("Class / Grade *") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = schoolName,
                onValueChange = { schoolName = it },
                label = { Text("School Name (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = monthlyFee,
                onValueChange = { monthlyFee = it; feeError = false },
                label = { Text("Monthly Tuition Fee (₹) *") },
                isError = feeError,
                supportingText = { if (feeError) Text("Enter a valid amount") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    // Validate required fields
                    nameError = fullName.isBlank()
                    mobileError = mobileNumber.trim().length < 10
                    val feeValue = monthlyFee.toDoubleOrNull()
                    feeError = feeValue == null || feeValue <= 0.0

                    if (!nameError && !mobileError && !feeError) {
                        val studentToSave = Student(
                            id = existingStudent?.id ?: 0,
                            fullName = fullName.trim(),
                            parentName = parentName.trim(),
                            mobileNumber = mobileNumber.trim(),
                            classGrade = classGrade.trim(),
                            schoolName = schoolName.trim(),
                            monthlyFee = feeValue!!,
                            admissionDate = existingStudent?.admissionDate ?: System.currentTimeMillis(),
                            address = address.trim(),
                            notes = notes.trim(),
                            isActive = existingStudent?.isActive ?: true
                        )

                        if (isEditMode) {
                            viewModel.updateStudent(studentToSave)
                        } else {
                            viewModel.addStudent(studentToSave)
                        }
                        onSaveComplete()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(if (isEditMode) "Save Changes" else "Add Student")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
