package com.sunny.studentfeemanager.data.repository

import com.sunny.studentfeemanager.data.dao.FeeRecordDao
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.PaymentMethod
import com.sunny.studentfeemanager.data.model.PaymentStatus
import com.sunny.studentfeemanager.data.model.Student
import com.sunny.studentfeemanager.util.FeeCycleCalculator
import kotlinx.coroutines.flow.Flow

class FeeRecordRepository(private val feeRecordDao: FeeRecordDao) {

    val allFeeRecords: Flow<List<FeeRecord>> = feeRecordDao.getAllFeeRecords()

    fun getRecordsForStudent(studentId: Long): Flow<List<FeeRecord>> {
        return feeRecordDao.getRecordsForStudent(studentId)
    }

    fun getTotalCollectedInRange(startMillis: Long, endMillis: Long): Flow<Double> {
        return feeRecordDao.getTotalCollectedInRange(startMillis, endMillis)
    }

    /**
     * Call this whenever we need to make sure a student's fee records are up to date.
     * It looks at their admission date, figures out every cycle that should exist by now
     * (using FeeCycleCalculator, which handles the custom due-date + clamping logic),
     * and creates any missing FeeRecord rows as UNPAID.
     *
     * Safe to call repeatedly -- it only inserts cycles that don't already exist.
     */
    suspend fun ensureFeeRecordsUpToDate(student: Student) {
        val cycles = FeeCycleCalculator.getAllCyclesUpToToday(student.admissionDate)

        for (cycle in cycles) {
            val existing = feeRecordDao.getRecordForCycle(student.id, cycle.cycleStartMillis)
            if (existing == null) {
                feeRecordDao.insertFeeRecord(
                    FeeRecord(
                        studentId = student.id,
                        cycleStartDate = cycle.cycleStartMillis,
                        cycleEndDate = cycle.cycleEndMillis,
                        monthlyFee = student.monthlyFee,
                        amountPaid = 0.0,
                        status = PaymentStatus.UNPAID
                    )
                )
            }
        }
    }

    /**
     * Records or updates a payment against a specific fee cycle.
     * Automatically calculates whether the cycle is now PAID / PARTIAL / UNPAID.
     */
    suspend fun recordPayment(
        record: FeeRecord,
        amountPaid: Double,
        paymentDate: Long,
        paymentMethod: PaymentMethod,
        remarks: String
    ) {
        val newStatus = when {
            amountPaid >= record.monthlyFee -> PaymentStatus.PAID
            amountPaid > 0.0 -> PaymentStatus.PARTIAL
            else -> PaymentStatus.UNPAID
        }

        val updated = record.copy(
            amountPaid = amountPaid,
            paymentDate = paymentDate,
            paymentMethod = paymentMethod,
            remarks = remarks,
            status = newStatus
        )

        feeRecordDao.updateFeeRecord(updated)
    }
}
