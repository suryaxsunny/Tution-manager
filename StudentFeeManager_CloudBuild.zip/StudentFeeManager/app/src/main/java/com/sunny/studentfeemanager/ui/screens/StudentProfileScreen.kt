package com.sunny.studentfeemanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.PaymentMethod
import com.sunny.studentfeemanager.data.model.PaymentStatus
import com.sunny.studentfeemanager.data.model.Student
import com.sunny.studentfeemanager.ui.theme.*
import com.sunny.studentfeemanager.ui.viewmodel.FeeRecordViewModel
import com.sunny.studentfeemanager.ui.viewmodel.StudentViewModel
import com.sunny.studentfeemanager.util.FeeCycleCalculator
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfileScreen(
    studentId: Long,
    studentViewModel: StudentViewModel = viewModel(),
    feeViewModel: FeeRecordViewModel = viewModel(),
    onBackClick: () -> Unit,
    onEditClick: () -> Unit,
    onSendReminderClick: (Student, FeeRecord?) -> Unit
) {
    val student by studentViewModel.getStudentById(studentId).collectAsState(initial = null)
    val records by feeViewModel.getRecordsForStudent(studentId).collectAsState(initial = emptyList())

    var selectedRecord by remember { mutableStateOf<FeeRecord?>(null) }

    student?.let { s ->
        val totalPaid = records.sumOf { it.amountPaid }
        val totalPending = records.sumOf { it.remainingBalance }
        val dueDay = FeeCycleCalculator.getDueDay(s.admissionDate)
        val latestRecord = records.maxByOrNull { it.cycleStartDate }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(s.fullName) },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = onEditClick) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                item {
                    // Fee cycle info chip
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(
                            text = "Fee due every ${dueDay}${ordinalSuffix(dueDay)} of the month · ₹${s.monthlyFee.toInt()}",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            title = "Total Paid",
                            value = "₹${totalPaid.toInt()}",
                            modifier = Modifier.weight(1f),
                            valueColor = MaterialTheme.colorScheme.primary
                        )
                        StatCard(
                            title = "Total Pending",
                            value = "₹${totalPending.toInt()}",
                            modifier = Modifier.weight(1f),
                            valueColor = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onSendReminderClick(s, latestRecord) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Send WhatsApp Reminder")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        "Payment History",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(records.sortedByDescending { it.cycleStartDate }, key = { it.id }) { record ->
                    FeeRecordRow(record = record, onClick = { selectedRecord = record })
                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (records.isEmpty()) {
                    item {
                        Text(
                            "No fee cycles yet.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 20.dp)
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(40.dp)) }
            }
        }

        // Payment recording dialog
        selectedRecord?.let { record ->
            RecordPaymentDialog(
                record = record,
                studentName = s.fullName,
                onDismiss = { selectedRecord = null },
                onSave = { amount, date, method, remarks ->
                    feeViewModel.recordPayment(record, amount, date, method, remarks)
                    selectedRecord = null
                }
            )
        }
    }
}

@Composable
fun FeeRecordRow(record: FeeRecord, onClick: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }

    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${dateFormat.format(Date(record.cycleStartDate))} – ${dateFormat.format(Date(record.cycleEndDate))}",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "₹${record.amountPaid.toInt()} of ₹${record.monthlyFee.toInt()} paid" +
                        (record.paymentDate?.let { " · ${dateFormat.format(Date(it))}" } ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            StatusBadge(status = record.status)
        }
    }
}

@Composable
fun StatusBadge(status: PaymentStatus) {
    val (bg, text, label) = when (status) {
        PaymentStatus.PAID -> Triple(
            androidx.compose.ui.graphics.Color(0xFFDCF5E1),
            androidx.compose.ui.graphics.Color(0xFF2E7D32),
            "PAID"
        )
        PaymentStatus.PARTIAL -> Triple(
            androidx.compose.ui.graphics.Color(0xFFFDEBD3),
            androidx.compose.ui.graphics.Color(0xFFEF6C00),
            "PARTIAL"
        )
        PaymentStatus.UNPAID -> Triple(
            androidx.compose.ui.graphics.Color(0xFFFBDADD),
            androidx.compose.ui.graphics.Color(0xFFC62828),
            "UNPAID"
        )
    }
    Surface(color = bg, shape = MaterialTheme.shapes.small) {
        Text(
            text = label,
            color = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentDialog(
    record: FeeRecord,
    studentName: String,
    onDismiss: () -> Unit,
    onSave: (amount: Double, dateMillis: Long, method: PaymentMethod, remarks: String) -> Unit
) {
    var amountText by remember { mutableStateOf(if (record.amountPaid > 0) record.amountPaid.toInt().toString() else "") }
    var selectedMethod by remember { mutableStateOf(record.paymentMethod ?: PaymentMethod.CASH) }
    var remarks by remember { mutableStateOf(record.remarks) }
    val paymentDateMillis = remember { record.paymentDate ?: System.currentTimeMillis() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Payment") },
        text = {
            Column {
                Text(
                    "$studentName · Fee ₹${record.monthlyFee.toInt()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount Paid (₹)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Payment Method", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentMethod.values().forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method },
                            label = { Text(method.name.replace("_", " "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Remarks (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = amountText.toDoubleOrNull() ?: 0.0
                onSave(amount, paymentDateMillis, selectedMethod, remarks.trim())
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun ordinalSuffix(n: Int): String {
    if (n in 11..13) return "th"
    return when (n % 10) {
        1 -> "st"
        2 -> "nd"
        3 -> "rd"
        else -> "th"
    }
}
