package com.sunny.studentfeemanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunny.studentfeemanager.data.model.FeeRecord
import com.sunny.studentfeemanager.data.model.PaymentStatus
import com.sunny.studentfeemanager.ui.theme.*
import com.sunny.studentfeemanager.ui.viewmodel.DashboardStats
import com.sunny.studentfeemanager.ui.viewmodel.FeeRecordViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * Home / Dashboard screen — redesigned to match the "Tuition Tracker" reference:
 * green gradient hero card, quick action buttons, 2x2 stat grid, recent payments.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: FeeRecordViewModel = viewModel(),
    onViewStudentsClick: () -> Unit,
    onAddStudentClick: () -> Unit,
    onRecordPaymentClick: () -> Unit
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val recentPayments by viewModel.recentPayments.collectAsState()

    val monthLabel = remember(stats) {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    "WELCOME BACK",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "Tuition Tracker",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        item { HeroCard(stats = stats, monthLabel = monthLabel) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickActionButton(
                    icon = Icons.Default.PersonAdd,
                    label = "Add Student",
                    modifier = Modifier.weight(1f),
                    onClick = onAddStudentClick
                )
                QuickActionButton(
                    icon = Icons.Default.Payments,
                    label = "Record Payment",
                    modifier = Modifier.weight(1f),
                    onClick = onRecordPaymentClick
                )
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MiniStatCard(
                        icon = Icons.Default.Groups,
                        iconTint = TextSecondary,
                        value = stats.totalStudents.toString(),
                        label = "Total Students",
                        modifier = Modifier.weight(1f)
                    )
                    MiniStatCard(
                        icon = Icons.Default.CheckCircle,
                        iconTint = PaidGreen,
                        value = "${stats.studentsPaidThisMonth}/${stats.totalStudents}",
                        label = "Paid This Month",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MiniStatCard(
                        icon = Icons.Default.ErrorOutline,
                        iconTint = PartialOrange,
                        value = stats.studentsWithPending.toString(),
                        label = "Yet to Pay",
                        modifier = Modifier.weight(1f)
                    )
                    MiniStatCard(
                        icon = Icons.Default.AccountBalanceWallet,
                        iconTint = UnpaidRed,
                        value = "₹${stats.pendingAmount.toInt()}",
                        label = "Total Outstanding",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Text(
                "Recent Payments",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (recentPayments.isEmpty()) {
            item { EmptyPaymentsCard() }
        } else {
            items(recentPayments, key = { it.id }) { record ->
                RecentPaymentRow(record)
            }
        }
    }
}

@Composable
fun HeroCard(stats: DashboardStats, monthLabel: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(GreenAccent, GreenPrimaryDark)
                )
            )
            .padding(22.dp)
    ) {
        Column {
            Text(
                "COLLECTED · ${monthLabel.uppercase()}",
                color = Color.White.copy(alpha = 0.75f),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "₹${stats.collectedThisMonth.toInt()}",
                color = Color.White,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroBadge(icon = Icons.Default.Schedule, text = "Pending ₹${stats.pendingAmount.toInt()}")
                HeroBadge(icon = Icons.Default.TrackChanges, text = "Target ₹${stats.totalMonthlyCollection.toInt()}")
            }
        }
    }
}

@Composable
fun HeroBadge(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SurfaceLight,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(vertical = 16.dp, horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        }
    }
}

@Composable
fun MiniStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SurfaceLight,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
    }
}

@Composable
fun EmptyPaymentsCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceMuted
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 36.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.ReceiptLong,
                contentDescription = null,
                tint = TextSecondary.copy(alpha = 0.5f),
                modifier = Modifier.size(38.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text("No payments yet", fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                "Add your first student, then record their monthly fee.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun RecentPaymentRow(record: FeeRecord) {
    val dateFormat = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceLight
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("₹${record.amountPaid.toInt()}", fontWeight = FontWeight.Bold, color = TextPrimary)
                record.paymentDate?.let {
                    Text(dateFormat.format(Date(it)), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
            StatusBadge(status = record.status)
        }
    }
}

